<?php
defined('BASEPATH') or exit('No direct script access allowed');
$config['module_name'] = 'multi_contact_sites_pro';
